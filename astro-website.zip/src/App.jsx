export default function HomePage() {
  return (
    <div style={{ backgroundColor: '#0B0F1A', color: 'white', minHeight: '100vh', fontFamily: 'sans-serif' }}>
      {/* Hero Section */}
      <div style={{ position: 'relative', height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '0 1rem' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundColor: 'black', opacity: 0.7, zIndex: 10 }} />
        <video
          autoPlay
          loop
          muted
          style={{ position: 'absolute', width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 }}
          src="/background-galaxy.mp4"
        />
        <h1 style={{ fontSize: '4rem', fontWeight: 'bold', zIndex: 20 }}>ASTRO</h1>
        <p style={{ fontSize: '1.25rem', fontStyle: 'italic', color: '#D1D5DB', zIndex: 20 }}>The Echo Stirs</p>
        <button style={{ marginTop: '1.5rem', padding: '0.75rem 2rem', backgroundColor: '#1D4ED8', color: 'white', borderRadius: '9999px', fontSize: '1.125rem', fontWeight: '600', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', zIndex: 20 }}>
          Enter the Astroverse
        </button>
      </div>
      ...
    </div>
  );
}
